import sklearn
import pandas
import numpy as np
    
def some_function(x):
    # Packages are imported and available from your bundled environment.
    # Use the libraries to do work
    a =  (np.sin(x)**2 + 2).tolist()
    return a
